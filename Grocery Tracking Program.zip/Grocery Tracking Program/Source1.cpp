#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <iomanip>

class ItemTracker {
private:
    std::map<std::string, int> itemFrequency;
    const std::string INPUT_FILE = "CS210_Project_Three_Input_File.txt";
    const std::string BACKUP_FILE = "frequency.dat";

public:
    ItemTracker();
    void readInputFile();
    void writeBackupFile();
    int getItemFrequency(const std::string& item);
    void printAllFrequencies();
    void printHistogram();
};

// Constructor
ItemTracker::ItemTracker() {
    readInputFile();
    writeBackupFile();
}

// Read input file and populate itemFrequency map
void ItemTracker::readInputFile() {
    std::ifstream inputFile(INPUT_FILE);
    std::string item;

    if (inputFile.is_open()) {
        while (inputFile >> item) {
            itemFrequency[item]++;
        }
        inputFile.close();
    }
    else {
        std::cerr << "Error: Unable to open input file" << std::endl;
    }
}

// Write backup file with item frequencies
void ItemTracker::writeBackupFile() {
    std::ofstream backupFile(BACKUP_FILE);

    if (backupFile.is_open()) {
        for (const auto& pair : itemFrequency) {
            backupFile << pair.first << " " << pair.second << std::endl;
        }
        backupFile.close();
    }
    else {
        std::cerr << "Error: Unable to create backup file" << std::endl;
    }
}

// Get frequency of a specific item
int ItemTracker::getItemFrequency(const std::string& item) {
    return itemFrequency[item];
}

// Print all item frequencies
void ItemTracker::printAllFrequencies() {
    for (const auto& pair : itemFrequency) {
        std::cout << std::left << std::setw(20) << pair.first << pair.second << std::endl;
    }
}

// Print histogram of item frequencies
void ItemTracker::printHistogram() {
    for (const auto& pair : itemFrequency) {
        std::cout << std::left << std::setw(20) << pair.first;
        for (int i = 0; i < pair.second; i++) {
            std::cout << "*";
        }
        std::cout << std::endl;
    }
}

int main() {
    ItemTracker tracker;
    int choice;
    std::string item;

    do {
        std::cout << "\n1. Look up item frequency"
            << "\n2. Print all item frequencies"
            << "\n3. Print histogram"
            << "\n4. Exit"
            << "\nEnter your choice: ";
        std::cin >> choice;

        switch (choice) {
        case 1:
            std::cout << "Enter item name: ";
            std::cin >> item;
            std::cout << "Frequency of " << item << ": " << tracker.getItemFrequency(item) << std::endl;
            break;
        case 2:
            tracker.printAllFrequencies();
            break;
        case 3:
            tracker.printHistogram();
            break;
        case 4:
            std::cout << "Exiting program." << std::endl;
            break;
        default:
            std::cout << "Invalid choice. Please try again." << std::endl;
        }
    } while (choice != 4);

    return 0;
}