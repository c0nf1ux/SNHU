// ProjectOne.cpp
// SNHU CS-210: Programming Languages
// Heath Davis
// 9/22/2024

#include <iostream>
#include <string>
#include <limits>
#include <iomanip>
using namespace std;

// Function prototypes
string nCharString(size_t n, char c);
string twoDigitString(unsigned int n);
string formatTime24(unsigned int h, unsigned int m, unsigned int s);
string formatTime12(unsigned int h, unsigned int m, unsigned int s);
void printMenu(const string strings[], unsigned int numStrings, unsigned char width);
unsigned int getMenuChoice(unsigned int maxChoice);
void displayClocks(unsigned int h, unsigned int m, unsigned int s);
void addOneHour();
void addOneMinute();
void addOneSecond();
void mainMenu();

// Global variables to store time
unsigned int hours = 0, minutes = 0, seconds = 0;

// Helper functions
unsigned int getHour() { return hours; }
void setHour(unsigned int h) { hours = h % 24; }
unsigned int getMinute() { return minutes; }
void setMinute(unsigned int m) { minutes = m % 60; }
unsigned int getSecond() { return seconds; }
void setSecond(unsigned int s) { seconds = s % 60; }

string nCharString(size_t n, char c) {
    return string(n, c);
}

string twoDigitString(unsigned int n) {
    ostringstream ss;
    ss << setw(2) << setfill('0') << n;
    return ss.str();
}

string formatTime24(unsigned int h, unsigned int m, unsigned int s) {
    return twoDigitString(h) + ":" + twoDigitString(m) + ":" + twoDigitString(s);
}

string formatTime12(unsigned int h, unsigned int m, unsigned int s) {
    string period = (h < 12) ? "A M" : "P M";
    unsigned int hour12 = h % 12;
    if (hour12 == 0) hour12 = 12;
    return twoDigitString(hour12) + ":" + twoDigitString(m) + ":" + twoDigitString(s) + " " + period;
}

void printMenu(const string strings[], unsigned int numStrings, unsigned char width) {
    cout << nCharString(width, '*') << endl;

    for (unsigned int i = 0; i < numStrings; i++) {
        string item = strings[i];
        unsigned int itemNumber = i + 1;
        unsigned int itemLength = 6 + to_string(itemNumber).length() + item.length();
        unsigned int spacesNeeded = width - itemLength;

        cout << "* " << itemNumber << " - " << item
            << nCharString(spacesNeeded, ' ') << "*" << endl;

        if (i < numStrings - 1) {
            cout << endl;
        }
    }

    cout << nCharString(width, '*') << endl;
}

unsigned int getMenuChoice(unsigned int maxChoice) {
    unsigned int choice;
    while (true) {
        cin >> choice;
        if (choice >= 1 && choice <= maxChoice) {
            return choice;
        }
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Invalid input. Please enter a number between 1 and " << maxChoice << "." << endl;
    }
}

void displayClocks(unsigned int h, unsigned int m, unsigned int s) {
    cout << nCharString(27, '*') << nCharString(3, ' ') << nCharString(27, '*') << endl;
    cout << "*" << nCharString(6, ' ') << "12-HOUR CLOCK" << nCharString(6, ' ') << "*"
        << nCharString(3, ' ')
        << "*" << nCharString(6, ' ') << "24-HOUR CLOCK" << nCharString(6, ' ') << "*" << endl;
    cout << endl;
    cout << "*" << nCharString(6, ' ') << formatTime12(h, m, s) << nCharString(7, ' ') << "*"
        << nCharString(3, ' ')
        << "*" << nCharString(8, ' ') << formatTime24(h, m, s) << nCharString(9, ' ') << "*" << endl;
    cout << nCharString(27, '*') << nCharString(3, ' ') << nCharString(27, '*') << endl;
}

void addOneHour() {
    unsigned int currentHour = getHour();
    setHour(currentHour + 1);
}

void addOneMinute() {
    unsigned int currentMinute = getMinute();
    if (currentMinute < 59) {
        setMinute(currentMinute + 1);
    }
    else {
        setMinute(0);
        addOneHour();
    }
}

void addOneSecond() {
    unsigned int currentSecond = getSecond();
    if (currentSecond < 59) {
        setSecond(currentSecond + 1);
    }
    else {
        setSecond(0);
        addOneMinute();
    }
}

void mainMenu() {
    const string menuOptions[] = { "Add One Hour", "Add One Minute", "Add One Second", "Exit Program" };
    unsigned int choice;
    do {
#ifdef _WIN32
        system("cls");
#else
        system("clear");
#endif
        displayClocks(getHour(), getMinute(), getSecond());
        printMenu(menuOptions, 4, 26);
        choice = getMenuChoice(4);

        switch (choice) {
        case 1: addOneHour(); break;
        case 2: addOneMinute(); break;
        case 3: addOneSecond(); break;
        }
    } while (choice != 4);
}

int main() {
    cout << "Welcome to the Clock Program!" << endl;
    mainMenu();
    cout << "Thank you for using the Clock Program. Goodbye!" << endl;
    return 0;
}